package com.f1000.rest.exception;

public class IncorrectCurrencyTypeException extends Exception {
	
	public IncorrectCurrencyTypeException(String message) {
		super(message);
	}
}
