package com.f1000.rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication; 

@SpringBootApplication 
public class F1000SpringBootApplication {

    public static void main(String[] args) {
        SpringApplication.run(F1000SpringBootApplication.class, args);
    }
}
