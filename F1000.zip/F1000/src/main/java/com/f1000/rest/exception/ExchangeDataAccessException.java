package com.f1000.rest.exception;

public class ExchangeDataAccessException extends Exception {
	
	public ExchangeDataAccessException(String message) {
		super(message);
	}
}
