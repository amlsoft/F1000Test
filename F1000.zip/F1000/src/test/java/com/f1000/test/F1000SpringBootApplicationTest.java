package com.f1000.test;

import org.junit.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@AutoConfigureMockMvc
public class F1000SpringBootApplicationTest {

	
	@Test
	public void contextLoads() {
	}

}
